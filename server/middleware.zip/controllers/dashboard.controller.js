// src/controllers/dashboard.controller.js
const { todayWater } = require('./careTasks.controller');

// expose the same "today water" data under /api/dashboard/water-tasks
exports.waterTasks = todayWater;
