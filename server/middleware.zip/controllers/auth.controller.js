// server/controllers/authController.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const JWT_EXPIRES_IN = '7d';

const sanitizeUser = (u) => ({
  _id: u._id,
  first_Name: u.first_Name || '',
  LastName: u.LastName || '',
  emailId: u.emailId,
  roles: u.roles || ['user'],
});

exports.register = async (req, res) => {
  try {
    let { first_Name = '', LastName = '', emailId, password, rePassword } = req.body || {};

    if (!emailId || !password) {
      return res.status(400).json({ message: 'emailId and password are required' });
    }
    emailId = String(emailId).trim().toLowerCase();

    if (rePassword != null && password !== rePassword) {
      return res.status(400).json({ message: 'Passwords do not match' });
    }

    const exists = await User.findOne({ emailId });
    if (exists) {
      return res.status(409).json({ message: 'Email already registered' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const user = await User.create({
      first_Name,
      LastName,
      emailId,
      password_hash,
      roles: ['user'],
      created_at: new Date(),
    });

    return res.status(201).json({ user: sanitizeUser(user) });
  } catch (err) {
    if (err && err.code === 11000 && err.keyPattern?.emailId) {
      return res.status(409).json({ message: 'Email already registered' });
    }
    console.error('Register error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
};

exports.login = async (req, res) => {
  try {
    let { emailId, password } = req.body || {};
    if (!emailId || !password) {
      return res.status(400).json({ message: 'emailId and password are required' });
    }
    emailId = String(emailId).trim().toLowerCase();

    const user = await User.findOne({ emailId });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });

    user.last_login_at = new Date();
    await user.save();

    const token = jwt.sign(
      { sub: user._id.toString(), roles: user.roles || ['user'] },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return res.json({ token, user: sanitizeUser(user) });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
};
