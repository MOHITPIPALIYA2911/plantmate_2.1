const router = require('express').Router();
const auth = require('../middleware/authRequired');
const { waterTasks } = require('../controllers/dashboard.controller');

router.get('/water-tasks', auth, waterTasks);

module.exports = router;
