const router = require('express').Router();
const auth = require('../middleware/authRequired');
const ctrl = require('../controllers/plants.controller');

router.get('/', auth, ctrl.listCatalog);
router.get('/suggestions', auth, ctrl.suggestions);

module.exports = router;
