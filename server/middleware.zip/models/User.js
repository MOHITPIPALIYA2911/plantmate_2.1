// server/models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    first_Name: { type: String, trim: true },
    LastName: { type: String, trim: true },
    emailId: {
      type: String,
      required: true,              // ← must be present
      unique: true,
      lowercase: true,
      trim: true,
    },
    password_hash: { type: String, required: true },
    roles: { type: [String], default: ['user'] },
    created_at: { type: Date, default: Date.now },
    last_login_at: { type: Date },
  },
  { versionKey: false }
);

// Extra safety: only enforce uniqueness for string emails
// (helps avoid dup-key on null if a bad doc ever slips through)
userSchema.index(
  { emailId: 1 },
  { unique: true, partialFilterExpression: { emailId: { $type: 'string' } } }
);

module.exports = mongoose.model('User', userSchema);
