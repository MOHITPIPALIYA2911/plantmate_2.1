require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookie = require('cookie-parser');
const mongoose = require('mongoose');

const authRoutes = require('./routes/auth.routes');
const profileRoutes = require('./routes/profile.routes');
const spacesRoutes = require('./routes/spaces.routes');
const plantsRoutes = require('./routes/plants.routes');
const userPlantsRoutes = require('./routes/userPlants.routes');
const careTasksRoutes = require('./routes/careTasks.routes');
const calendarRoutes = require('./routes/calendar.routes');
const dashboardRoutes = require('./routes/dashboard.routes');


const app = express();
app.use(cors({
  origin: "http://localhost:3000",
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization"],
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
}));
app.use(express.json());
app.use(cookie());

mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/plantmate');

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/auth', authRoutes);
app.use('/profiles', profileRoutes);
app.use('/api/spaces', spacesRoutes);
app.use('/api/plants', plantsRoutes);
app.use('/api/user-plants', userPlantsRoutes);
app.use('/api/care-tasks', careTasksRoutes);
app.use('/api/calendar', calendarRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

const port = process.env.PORT || 7777;
app.listen(port, () => console.log('Server listening on ' + port));
